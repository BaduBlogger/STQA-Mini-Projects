package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class EngineModTest {

	@Test
	public void testCompute() {
		Engine e = new Engine();
		String result = e.compute("5.0","2.0","mod");
		assertEquals("Modulus",result,"1.0");
	}

}
