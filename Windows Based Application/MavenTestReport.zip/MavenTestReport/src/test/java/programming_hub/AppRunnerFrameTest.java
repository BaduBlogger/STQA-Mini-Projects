package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppRunnerFrameTest {
	
	@Test
	public void testMain() {
		Calculator calculator = new Calculator(450,600);
        Boolean status = AppRunner.status;
        calculator.setVisible(status);
    	assertSame(status,true);
	}
}
