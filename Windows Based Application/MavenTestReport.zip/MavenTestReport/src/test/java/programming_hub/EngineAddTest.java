package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class EngineAddTest {

	@Test
	public void testCompute() {
		Engine e = new Engine();
		String result = e.compute("2.0","2.0","+");
		assertEquals("Addition",result,"4.0");
	}

}
