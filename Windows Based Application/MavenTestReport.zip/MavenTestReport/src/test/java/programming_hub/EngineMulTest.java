package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class EngineMulTest {

	@Test
	public void testCompute() {
		Engine e = new Engine();
		String result = e.compute("2.0","2.0","\u00D7");
		assertEquals("Multiplication",result,"4.0");
	}

}
