package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class HelperScreenRatioTest {
	public HelperScreenRatioTest()
	{
		h = new Helper();
	}
	
	Helper h;
	@Test
	public void ScreenRatiotest() {
		double result = h.SCREEN_RATIO + h.KEYPAD_RATIO + h.FOOTER_RATIO;
		assertFalse(result==0.90);
	}
	
	@Test
	public void ScreenDivisiontest() {
		double result = h.INPUT_DISPLAY_RATIO + h.OUTPUT_DISPLAY_RATIO;
		assertEquals(result,1.0,0.001);
	}

}
