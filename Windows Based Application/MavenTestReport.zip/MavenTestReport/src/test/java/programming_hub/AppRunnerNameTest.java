package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppRunnerNameTest {

	@Test
	public void testMain() {
		String titleName = AppRunner.titleName;
		assertEquals(titleName,"Scientific Calculator");
	}
}
