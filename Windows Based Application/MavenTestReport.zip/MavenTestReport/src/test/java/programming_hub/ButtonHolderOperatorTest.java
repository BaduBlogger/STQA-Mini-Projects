  package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class ButtonHolderOperatorTest {

	@Test
	public void testIsOperator() {
		ButtonHolder b = new ButtonHolder("operator","add","+","+");
		boolean result = b.isOperator();
		assertTrue(result==true);
	}
	
	@Test
	public void testIsScreenText() {
		ButtonHolder b = new ButtonHolder("operator","subtract","\u02D7","\u02D7");
		String buttonText="\u02D7";
		assertTrue(buttonText.equals(b.screenText));
	}
	
	@Test
	public void testIsNumberModifier() {
		ButtonHolder b = new ButtonHolder("number_modifier","point",".",".");
		String pureName="point";
		assertTrue(pureName.equals(b.pureName));
	}

}
