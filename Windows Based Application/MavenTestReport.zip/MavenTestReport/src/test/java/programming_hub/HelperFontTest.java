package programming_hub;

import static org.junit.Assert.*;

import java.awt.Font;

import org.junit.Test;

public class HelperFontTest {

	@Test
	public void ScreenFonttest() {
		Helper h = new Helper();
		String fontName = h.SCREEN_FONT.getFontName();
		assertTrue(fontName.equals("Times New Roman Bold"));
	}
	
	@Test
	public void ScreenFontSizetest() {
		Helper h = new Helper();
		int fontSize = h.SCREEN_FONT.getSize();
		assertNotSame(fontSize,36);
	}	
	
	@Test
	public void KeyFonttest() {
		Helper h = new Helper();
		String fontName = h.KEY_FONT_MD.getFontName();
		assertEquals(fontName,"Times New Roman");
	}	
	
	@Test
	public void KeyFontSizetest() {
		Helper h = new Helper();
		int fontSize = h.KEY_FONT_MD.getSize();
		assertTrue(fontSize==20);
	}
	
	@Test
	public void KeyFontSMtest() {
		Helper h = new Helper();
		String fontName = h.KEY_FONT_SM.getFontName();
		assertEquals(fontName,"Times New Roman");
	}	
	
	@Test
	public void KeyFontSizeSMtest() {
		Helper h = new Helper();
		int fontSize = h.KEY_FONT_SM.getSize();
		assertTrue(fontSize==15);
	}
	

}
