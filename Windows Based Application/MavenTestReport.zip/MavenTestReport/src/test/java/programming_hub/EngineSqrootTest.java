package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class EngineSqrootTest {

	@Test
	public void testComputeSciFun() {
		Engine e = new Engine();
		String result = e.computeSciFun("square_root","64.0");
		assertEquals("square_root",result,"8.0");
	}

}
