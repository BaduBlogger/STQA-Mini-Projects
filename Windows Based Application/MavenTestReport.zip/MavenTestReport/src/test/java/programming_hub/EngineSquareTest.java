package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class EngineSquareTest {

	@Test
	public void testComputeSciFun() {
		Engine e = new Engine();
		String result = e.computeSciFun("square","2.0");
		assertEquals("square",result,"4.0");
	}

}
