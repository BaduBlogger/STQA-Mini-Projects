package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class EngineTrignometryTest {

	@Test
	public void testComputeSciFun() {
		Engine e = new Engine();
		String result = e.computeSciFun("sin","0");
		assertEquals(result,"0.0");
	}

}
