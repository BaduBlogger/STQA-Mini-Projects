package programming_hub;
import javax.swing.*;
import programming_hub.Calculator;

public class AppRunner
{
	
	static boolean status = true;
	final static String titleName = "Scientific Calculator";
	
    public static void main(String[] args){
    	Calculator calculator = new Calculator(450, 600);
        calculator.setTitle(titleName);
        calculator.getContentPane().setBackground(Helper.darkGrey);
        calculator.setLocationRelativeTo(null);
        calculator.setIcon("assets/calculator-icon.png");
        calculator.setVisible(status);
    }
}
