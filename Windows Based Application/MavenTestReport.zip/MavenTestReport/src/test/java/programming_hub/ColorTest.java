package programming_hub;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Test;

public class ColorTest {
	public ColorTest()
	{
		h = new Helper();
	}
	Helper h;
	@Test
	public void testGetFoundOperator() {
		Helper h = new Helper();
		Color darkGreyNew = new Color(110, 119, 129);
		assertTrue(darkGreyNew.equals(h.darkGrey));
		System.out.println("true");
	}
	
	@Test
	 public void testGreen()
	 {
		Color GreenNew = new Color(91, 178, 91);
		assertTrue(GreenNew.equals(h.GREEN));
		System.out.println("true");
	 }
	
	@Test
	 public void testWhite()
	 {
		Color WhiteNew = new Color(247, 247, 247);
		assertTrue(WhiteNew.equals(h.WHITE));
		System.out.println("true");
	 }
	
	@Test
	public void falseTest()
	{
		Color BlueNew = new Color(0, 0, 255);
		assertFalse(BlueNew.equals(h.WHITE));
		System.out.println("false");
	}

}
