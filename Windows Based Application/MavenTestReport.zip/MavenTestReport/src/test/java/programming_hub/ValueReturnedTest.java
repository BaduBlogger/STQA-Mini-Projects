package programming_hub;

import static org.junit.Assert.*;
import org.junit.Test;

public class ValueReturnedTest 
{

	@Test
	public void testComputeSciFun() 
	{
		String result = null;
		Engine e = new Engine();
		result = e.computeSciFun("square","2.0");
		assertNotNull(result);
	}

	@Test
	public void testCompute() 
	{
		Engine e = new Engine();
		String result = e.compute("2.0","2.0","+");
		assertNotNull(result);
	}
}
