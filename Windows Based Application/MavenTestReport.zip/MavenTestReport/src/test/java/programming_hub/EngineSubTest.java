package programming_hub;

import static org.junit.Assert.*;

import org.junit.Test;

public class EngineSubTest {

	@Test
	public void testCompute() {
		Engine e = new Engine();
		String result = e.compute("2.0","2.0","\u02D7");
		assertEquals("Substraction",result,"0.0");
	}

}
